﻿namespace DefiningClasses
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person1 = new Person(5);
            Console.WriteLine(person1.Age);
        }
    }
}
