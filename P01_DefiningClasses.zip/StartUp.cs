﻿namespace DefiningClasses
{
    using System;

    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person1 = new Person();

            person1.Name = "Pesho";
            person1.Age = 20;
        }
    }
}
